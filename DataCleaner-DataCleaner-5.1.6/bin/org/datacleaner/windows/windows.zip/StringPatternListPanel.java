/**
 * DataCleaner (community edition)
 * Copyright (C) 2014 Neopost - Customer Information Management
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.datacleaner.panels;

import java.awt.GridBagConstraints;
import java.util.Arrays;

import javax.inject.Inject;
import javax.swing.Box;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

import org.datacleaner.bootstrap.WindowContext;
import org.datacleaner.configuration.DataCleanerConfiguration;
import org.datacleaner.reference.RegexStringPattern;
import org.datacleaner.reference.SimpleStringPattern;
import org.datacleaner.reference.StringPattern;
import org.datacleaner.reference.regexswap.RegexSwapStringPattern;
import org.datacleaner.regexswap.RegexSwapDialog;
import org.datacleaner.user.MutableReferenceDataCatalog;
import org.datacleaner.user.ReferenceDataChangeListener;
import org.datacleaner.user.UserPreferences;
import org.datacleaner.util.IconUtils;
import org.datacleaner.util.ImageManager;
import org.datacleaner.util.WidgetFactory;
import org.datacleaner.util.WidgetUtils;
import org.datacleaner.widgets.DCLabel;
import org.datacleaner.widgets.DCPopupBubble;
import org.datacleaner.widgets.HelpIcon;
import org.datacleaner.windows.ReferenceDataDialog;
import org.datacleaner.windows.RegexStringPatternDialog;
import org.datacleaner.windows.SimpleStringPatternDialog;
import org.jdesktop.swingx.VerticalLayout;

public class StringPatternListPanel extends DCPanel implements ReferenceDataChangeListener<StringPattern> {

    private static final long serialVersionUID = 1L;

    private static final ImageManager imageManager = ImageManager.get();
    private final DataCleanerConfiguration _configuration;
    private final MutableReferenceDataCatalog _catalog;
    private final DCPanel _listPanel;
    private final DCGlassPane _glassPane;
    private final WindowContext _windowContext;
    private final UserPreferences _userPreferences;

    @Inject
    protected StringPatternListPanel(final DCGlassPane glassPane, final DataCleanerConfiguration configuration,
            final WindowContext windowContext, final UserPreferences userPreferences) {
        super(WidgetUtils.COLOR_DEFAULT_BACKGROUND);
        _glassPane = glassPane;
        _configuration = configuration;
        _windowContext = windowContext;
        _userPreferences = userPreferences;
        _catalog = (MutableReferenceDataCatalog) _configuration.getReferenceDataCatalog();
        _catalog.addStringPatternListener(this);

        _listPanel = new DCPanel();
        _listPanel.setLayout(new VerticalLayout(4));

        updateComponents();

        final DCLabel newStringPatternsLabel = DCLabel.dark("创建新的字符串模式:");
        newStringPatternsLabel.setFont(WidgetUtils.FONT_HEADER1);

        final DCLabel existingStringPatternsLabel = DCLabel.dark("现有的字符串模式:");
        existingStringPatternsLabel.setFont(WidgetUtils.FONT_HEADER1);

        setLayout(new VerticalLayout(10));
        add(newStringPatternsLabel);
        add(createNewStringPatternsPanel());
        add(Box.createVerticalStrut(10));
        add(existingStringPatternsLabel);
        setBorder(new EmptyBorder(10, 10, 10, 0));
        add(_listPanel);
    }

    private static String getDescription(final StringPattern stringPattern) {
        if (stringPattern.getDescription() != null) {
            return stringPattern.getDescription();
        }
        final String description;
        if (stringPattern instanceof RegexSwapStringPattern) {
            description = ((RegexSwapStringPattern) stringPattern).getRegex().getExpression();
        } else if (stringPattern instanceof RegexStringPattern) {
            description = ((RegexStringPattern) stringPattern).getExpression();
        } else if (stringPattern instanceof SimpleStringPattern) {
            description = ((SimpleStringPattern) stringPattern).getExpression();
        } else {
            description = "";
        }

        if (description == null) {
            return "";
        }
        if (description.length() > 30) {
            return description.substring(0, 27) + "...";
        }
        return description;
    }

    private DCPanel createNewStringPatternsPanel() {

        final JButton simpleStringPatternButton = createButton(IconUtils.STRING_PATTERN_SIMPLE_IMAGEPATH,
                "<html><b>简单的字符串模式</b><br/>基于简单的字符串分隔而成的模式,如： 'Aaaaa 999'.</html>");
        simpleStringPatternButton
                .addActionListener(e -> new SimpleStringPatternDialog(_catalog, _windowContext).setVisible(true));

        final JButton regexStringPatternButton = createButton(IconUtils.STRING_PATTERN_REGEX_IMAGEPATH,
                "<html><b>正则表达式字符串模式</b><br/>一种非常灵活的字符串模式,基于正则表达式生成。 "
                        + "based on regular expressions.</html>");
        regexStringPatternButton
                .addActionListener(e -> new RegexStringPatternDialog(_catalog, _windowContext).setVisible(true));

        final JButton regexSwapStringPatternButton = createButton(IconUtils.STRING_PATTERN_REGEXSWAP_IMAGEPATH,
                "<html><b>浏览 RegexSwap</b><br/>从 DataCleaner的在线 RegexSwap下载模式.</html>");
        regexSwapStringPatternButton.addActionListener(
                e -> new RegexSwapDialog(_catalog, _windowContext, _userPreferences).setVisible(true));

        final HelpIcon helpIcon = new HelpIcon("<b>字符串模式</b><br>字符串模式提供了一种匹配字符串的模式， "
                + "它常常在有效性验证或半结构化的值或列分类很有用 .");

        final DCPanel panel =
                DCPanel.flow(simpleStringPatternButton, regexStringPatternButton, regexSwapStringPatternButton,
                        Box.createHorizontalStrut(100), helpIcon);
        panel.setBorder(WidgetUtils.BORDER_LIST_ITEM);
        return panel;
    }

    private JButton createButton(final String imagePath, final String description) {
        final JButton button = WidgetFactory.createImageButton(imageManager.getImageIcon(imagePath));

        final DCPopupBubble popupBubble = new DCPopupBubble(_glassPane, description, 0, 0, imagePath);
        popupBubble.attachTo(button);

        return button;
    }

    private void updateComponents() {
        _listPanel.removeAll();

        final String[] names = _catalog.getStringPatternNames();
        Arrays.sort(names);

        final Icon icon = imageManager.getImageIcon("images/model/stringpattern.png");

        for (final String name : names) {
            final StringPattern stringPattern = _catalog.getStringPattern(name);

            final DCLabel stringPatternLabel =
                    DCLabel.dark("<html><b>" + name + "</b><br/>" + getDescription(stringPattern) + "</html>");
            stringPatternLabel.setIcon(icon);
            stringPatternLabel.setMaximumWidth(ReferenceDataDialog.REFERENCE_DATA_ITEM_MAX_WIDTH);

            final JButton editButton = WidgetFactory.createSmallButton(IconUtils.ACTION_EDIT);
            editButton.setToolTipText("编辑字符串模式");

            if (stringPattern instanceof RegexStringPattern) {
                editButton.addActionListener(e -> {
                    final RegexStringPatternDialog dialog =
                            new RegexStringPatternDialog((RegexStringPattern) stringPattern, _catalog, _windowContext);
                    dialog.setVisible(true);
                });
            } else if (stringPattern instanceof SimpleStringPattern) {
                editButton.addActionListener(e -> {
                    final SimpleStringPatternDialog dialog =
                            new SimpleStringPatternDialog((SimpleStringPattern) stringPattern, _catalog,
                                    _windowContext);
                    dialog.setVisible(true);
                });
            } else {
                editButton.setEnabled(false);
            }

            final JButton removeButton = WidgetFactory.createSmallButton(IconUtils.ACTION_REMOVE_DARK);
            removeButton.setToolTipText("移除字符串模式");
            removeButton.addActionListener(e -> {
                final int result = JOptionPane.showConfirmDialog(StringPatternListPanel.this,
                        "Are you sure you wish to remove the string pattern '" + name + "'?", "Confirm remove",
                        JOptionPane.YES_NO_OPTION);
                if (result == JOptionPane.YES_OPTION) {
                    _catalog.removeStringPattern(stringPattern);
                }
            });

            final DCPanel stringPatternPanel = new DCPanel();
            stringPatternPanel.setBorder(WidgetUtils.BORDER_LIST_ITEM);
            WidgetUtils.addToGridBag(stringPatternLabel, stringPatternPanel, 0, 0, 1.0, 0.0);
            WidgetUtils.addToGridBag(editButton, stringPatternPanel, 1, 0, GridBagConstraints.EAST);
            WidgetUtils.addToGridBag(removeButton, stringPatternPanel, 2, 0, GridBagConstraints.EAST);
            _listPanel.add(stringPatternPanel);
        }

        if (names.length == 0) {
            _listPanel.add(DCLabel.dark("(none)"));
        }

        updateUI();
    }

    @Override
    public void onAdd(final StringPattern stringPattern) {
        SwingUtilities.invokeLater(this::updateComponents);
    }

    @Override
    public void onRemove(final StringPattern stringPattern) {
        SwingUtilities.invokeLater(this::updateComponents);
    }

    @Override
    public void removeNotify() {
        super.removeNotify();
        _catalog.removeStringPatternListener(this);
    }

    @Override
    public void onChange(final StringPattern oldPattern, final StringPattern newPattern) {
        SwingUtilities.invokeLater(this::updateComponents);
    }
}
