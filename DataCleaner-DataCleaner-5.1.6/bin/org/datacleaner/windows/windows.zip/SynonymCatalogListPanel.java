/**
 * DataCleaner (community edition)
 * Copyright (C) 2014 Neopost - Customer Information Management
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.datacleaner.panels;

import java.awt.GridBagConstraints;
import java.util.Arrays;

import javax.inject.Inject;
import javax.swing.Box;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

import org.datacleaner.configuration.DataCleanerConfiguration;
import org.datacleaner.guice.InjectorBuilder;
import org.datacleaner.reference.DatastoreSynonymCatalog;
import org.datacleaner.reference.SynonymCatalog;
import org.datacleaner.reference.TextFileSynonymCatalog;
import org.datacleaner.user.MutableReferenceDataCatalog;
import org.datacleaner.user.ReferenceDataChangeListener;
import org.datacleaner.util.IconUtils;
import org.datacleaner.util.ImageManager;
import org.datacleaner.util.WidgetFactory;
import org.datacleaner.util.WidgetUtils;
import org.datacleaner.widgets.DCLabel;
import org.datacleaner.widgets.DCPopupBubble;
import org.datacleaner.widgets.HelpIcon;
import org.datacleaner.windows.DatastoreSynonymCatalogDialog;
import org.datacleaner.windows.ReferenceDataDialog;
import org.datacleaner.windows.TextFileSynonymCatalogDialog;
import org.jdesktop.swingx.VerticalLayout;

import com.google.inject.Injector;

public final class SynonymCatalogListPanel extends DCPanel implements ReferenceDataChangeListener<SynonymCatalog> {

    private static final long serialVersionUID = 1L;

    private static final ImageManager imageManager = ImageManager.get();
    private final DataCleanerConfiguration _configuration;
    private final MutableReferenceDataCatalog _catalog;
    private final DCPanel _listPanel;
    private final DCGlassPane _glassPane;
    private final InjectorBuilder _injectorBuilder;

    @Inject
    protected SynonymCatalogListPanel(final DCGlassPane glassPane, final DataCleanerConfiguration configuration,
            final InjectorBuilder injectorBuilder) {
        super(WidgetUtils.COLOR_DEFAULT_BACKGROUND);
        _glassPane = glassPane;
        _configuration = configuration;
        _injectorBuilder = injectorBuilder;
        _catalog = (MutableReferenceDataCatalog) _configuration.getReferenceDataCatalog();
        _catalog.addSynonymCatalogListener(this);

        _listPanel = new DCPanel();
        _listPanel.setLayout(new VerticalLayout(4));

        updateComponents();

        final DCLabel newSynonymCatalogsLabel = DCLabel.dark("创建新的同义词目录:");
        newSynonymCatalogsLabel.setFont(WidgetUtils.FONT_HEADER1);

        final DCLabel existingSynonymCatalogsLabel = DCLabel.dark("已有的同义词目录:");
        existingSynonymCatalogsLabel.setFont(WidgetUtils.FONT_HEADER1);

        setLayout(new VerticalLayout(10));
        add(newSynonymCatalogsLabel);
        add(createNewSynonymCatalogsPanel());
        add(Box.createVerticalStrut(10));
        add(existingSynonymCatalogsLabel);
        setBorder(new EmptyBorder(10, 10, 10, 0));
        add(_listPanel);
    }

    private static String getDescription(final SynonymCatalog synonymCatalog) {
        if (synonymCatalog.getDescription() != null) {
            return synonymCatalog.getDescription();
        }
        if (synonymCatalog instanceof TextFileSynonymCatalog) {
            return ((TextFileSynonymCatalog) synonymCatalog).getFilename();
        } else if (synonymCatalog instanceof DatastoreSynonymCatalog) {
            final DatastoreSynonymCatalog datastoreSynonymCatalog = (DatastoreSynonymCatalog) synonymCatalog;
            return datastoreSynonymCatalog.getDatastoreName() + ": " + datastoreSynonymCatalog
                    .getMasterTermColumnPath();
        }
        return "";
    }

    private DCPanel createNewSynonymCatalogsPanel() {

        final JButton textFileSynonymCatalogButton = createButton(IconUtils.SYNONYM_CATALOG_TEXTFILE_IMAGEPATH,
                "<html><b>文本文件同义词目录</b><br/>Synonyms from a file with master terms and "
                        + "comma-separated synonyms.</html>");
        textFileSynonymCatalogButton.addActionListener(e -> {
            final Injector injector = _injectorBuilder.with(TextFileSynonymCatalog.class, null).createInjector();
            final TextFileSynonymCatalogDialog dialog = injector.getInstance(TextFileSynonymCatalogDialog.class);
            dialog.setVisible(true);
        });

        final JButton datastoreSynonymCatalogButton = createButton(IconUtils.SYNONYM_CATALOG_DATASTORE_IMAGEPATH,
                "<html><b>数据库同义词目录</b><br/>基于注册的数据库列的同义词目录 .</html>");
        datastoreSynonymCatalogButton.addActionListener(e -> {
            final Injector injector = _injectorBuilder.with(DatastoreSynonymCatalog.class, null).createInjector();
            final DatastoreSynonymCatalogDialog dialog = injector.getInstance(DatastoreSynonymCatalogDialog.class);
            dialog.setVisible(true);
        });

        final HelpIcon helpIcon = new HelpIcon("<b>Synonym catalogs</b><br>"
                + "同义词目录是用于用正确的值替换奇值的引用数据. "
                + "在这个意义上的同义词也可以是如一个给定实体的标准术语值或代码.<br>"
                + "同义词可以在整个DataCleaner中用于匹配、替换值等等..");

        final DCPanel panel = DCPanel.flow(textFileSynonymCatalogButton, datastoreSynonymCatalogButton,
                Box.createHorizontalStrut(100), helpIcon);
        panel.setBorder(WidgetUtils.BORDER_LIST_ITEM);
        return panel;
    }

    private JButton createButton(final String imagePath, final String description) {
        final JButton button = WidgetFactory.createImageButton(imageManager.getImageIcon(imagePath));

        final DCPopupBubble popupBubble = new DCPopupBubble(_glassPane, description, 0, 0, imagePath);
        popupBubble.attachTo(button);

        return button;
    }

    private void updateComponents() {
        _listPanel.removeAll();

        final String[] names = _catalog.getSynonymCatalogNames();
        Arrays.sort(names);

        final Icon icon = imageManager.getImageIcon("images/model/synonym.png");

        for (final String name : names) {
            final SynonymCatalog synonymCatalog = _catalog.getSynonymCatalog(name);

            final DCLabel synonymCatalogLabel =
                    DCLabel.dark("<html><b>" + name + "</b><br/>" + getDescription(synonymCatalog) + "</html>");
            synonymCatalogLabel.setIcon(icon);
            synonymCatalogLabel.setMaximumWidth(ReferenceDataDialog.REFERENCE_DATA_ITEM_MAX_WIDTH);

            final JButton editButton = WidgetFactory.createSmallButton(IconUtils.ACTION_EDIT);
            editButton.setToolTipText("编辑同义词目录");

            if (synonymCatalog instanceof TextFileSynonymCatalog) {
                editButton.addActionListener(e -> {
                    final Injector injector =
                            _injectorBuilder.with(TextFileSynonymCatalog.class, synonymCatalog).createInjector();
                    final TextFileSynonymCatalogDialog dialog =
                            injector.getInstance(TextFileSynonymCatalogDialog.class);
                    dialog.setVisible(true);
                });
            } else if (synonymCatalog instanceof DatastoreSynonymCatalog) {
                editButton.addActionListener(e -> {
                    final Injector injector =
                            _injectorBuilder.with(DatastoreSynonymCatalog.class, synonymCatalog).createInjector();
                    final DatastoreSynonymCatalogDialog dialog =
                            injector.getInstance(DatastoreSynonymCatalogDialog.class);
                    dialog.setVisible(true);
                });
            } else {
                editButton.setEnabled(false);
            }

            final JButton removeButton = WidgetFactory.createSmallButton(IconUtils.ACTION_REMOVE_DARK);
            removeButton.setToolTipText("移除同义词目录");
            removeButton.addActionListener(e -> {
                final int result = JOptionPane.showConfirmDialog(SynonymCatalogListPanel.this,
                        "Are you sure you wish to remove the synonym catalog '" + name + "'?", "Confirm remove",
                        JOptionPane.YES_NO_OPTION);
                if (result == JOptionPane.YES_OPTION) {
                    _catalog.removeSynonymCatalog(synonymCatalog);
                }
            });

            final DCPanel synonymCatalogPanel = new DCPanel();
            synonymCatalogPanel.setBorder(WidgetUtils.BORDER_LIST_ITEM);
            WidgetUtils.addToGridBag(synonymCatalogLabel, synonymCatalogPanel, 0, 0, 1.0, 0.0);
            WidgetUtils.addToGridBag(editButton, synonymCatalogPanel, 1, 0, GridBagConstraints.EAST);
            WidgetUtils.addToGridBag(removeButton, synonymCatalogPanel, 2, 0, GridBagConstraints.EAST);
            _listPanel.add(synonymCatalogPanel);
        }

        if (names.length == 0) {
            _listPanel.add(DCLabel.dark("(none)"));
        }

        updateUI();
    }

    @Override
    public void onAdd(final SynonymCatalog synonymCatalog) {
        SwingUtilities.invokeLater(this::updateComponents);
    }

    @Override
    public void onRemove(final SynonymCatalog synonymCatalog) {
        SwingUtilities.invokeLater(this::updateComponents);
    }

    @Override
    public void removeNotify() {
        super.removeNotify();
        _catalog.removeSynonymCatalogListener(this);
    }

    @Override
    public void onChange(final SynonymCatalog oldReferenceData, final SynonymCatalog newReferenceData) {
        SwingUtilities.invokeLater(this::updateComponents);
    }
}
